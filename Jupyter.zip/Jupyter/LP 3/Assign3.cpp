#include<iostream>
using namespace std;

int main()
{
    int capacity = 10;
    int items = 4;
    int price[items+1]={0,3,7,2,9};
    int weight[items+1]={0,2,2,4,5};

    int dp[items+1][capacity+1];
    
}