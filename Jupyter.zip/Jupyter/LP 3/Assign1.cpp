#include <iostream>
using namespace std;

// Non-recursive (iterative) Fibonacci
int fibonacci_iterative(int n) {
    if (n <= 1) return n;
    int prev = 0, curr = 1;
    for (int i = 2; i <= n; ++i) {
        int temp = curr;
        curr = prev + curr;
        prev = temp;
    }
    return curr;
}

// Recursive Fibonacci
int fibonacci_recursive(int n) {
    if (n <= 1) return n;
    return fibonacci_recursive(n - 1) + fibonacci_recursive(n - 2);
}

int main() {
    int n;
    cout << "Enter a number: ";
    cin >> n;

    cout << "Iterative Fibonacci of " << n << ": " << fibonacci_iterative(n) << endl;
    cout << "Recursive Fibonacci of " << n << ": " << fibonacci_recursive(n) << endl;

    return 0;
}

//time complexity
//iterative : O(n)
//recursive : O(2^n)

//space complexity
//iterative : O(1)
//recursive : O(n)   ---->stack space