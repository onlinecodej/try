#include<iostream>
using namespace std;

int main(){
    int capacity = 10;  // Maximum capacity of the knapsack
    int items = 4;  // Number of items available to choose from
    int price[items + 1] = {0, 3, 7, 2, 9};  // Array storing profit (price) of each item, with 0 at index 0
    int wt[items + 1] = {0, 2, 2, 4, 5};  // Array storing weight of each item, with 0 at index 0

    // dp[i][j] will store the maximum profit for the first 'i' items with knapsack capacity 'j'
    int dp[items + 1][capacity + 1];

    // Fill the dp table
    for(int i = 0; i <= items; i++){  // Loop through each item (including 0th as base case)
        for(int j = 0; j <= capacity; j++){  // Loop through each capacity from 0 to maximum

            if(i == 0 || j == 0){
                // Base case: No items or 0 capacity means no profit
                dp[i][j] = 0;
            }
            else if(wt[i] <= j){
                // If the item's weight is less than or equal to the current capacity:
                // Take the maximum of:
                // 1. Not including the item (dp[i - 1][j])
                // 2. Including the item (price[i] + dp[i - 1][j - wt[i]])
                dp[i][j] = max(dp[i - 1][j], price[i] + dp[i - 1][j - wt[i]]);
            }
            else{
                // If the item's weight exceeds the current capacity, don't include it.
                // So, carry forward the previous maximum profit without this item
                dp[i][j] = dp[i - 1][j];
            }
        }
    }

    // Print the maximum profit possible with given items and capacity
    cout << "Maximum Profit Earned: " << dp[items][capacity] << "\n";
    return 0;
}
