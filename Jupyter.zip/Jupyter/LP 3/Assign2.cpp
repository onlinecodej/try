#include <bits/stdc++.h> // Includes all standard libraries

using namespace std;

// Node structure for Huffman Tree
struct MinHeapNode
{
    char data;                 // Character data (leaf nodes will store actual characters, internal nodes will store '$')
    int freq;                  // Frequency of the character
    MinHeapNode *left, *right; // Left and right children in the Huffman Tree

    // Constructor for initializing node with character and frequency
    MinHeapNode(char data, int freq)
    {
        left = right = nullptr; // Initially, left and right are null
        this->data = data;
        this->freq = freq;
    }
};

// Function to print Huffman Codes from the root of the Huffman Tree
void printCodes(struct MinHeapNode *root, string str)
{
    if (root == nullptr)
        return; // Base case: empty node

    // If it's a leaf node (contains character data), print the character and its code
    if (root->data != '$')
    {
        cout << root->data << ": " << str << endl;
    }

    // Recursive calls for left and right subtrees, appending "0" for left and "1" for right
    printCodes(root->left, str + "0");
    printCodes(root->right, str + "1");
}

// Comparator to order nodes in the priority queue by frequency
struct compare
{
    bool operator()(MinHeapNode *a, MinHeapNode *b)
    {
        return (a->freq > b->freq); // Higher frequency nodes have lower priority
    }
};

// Main function to build the Huffman Tree and generate codes
void HuffmanCode(char data[], int freq[], int size)
{
    MinHeapNode *left, *right, *temp;

    // Min-heap priority queue to store live nodes of Huffman Tree
    priority_queue<MinHeapNode *, vector<MinHeapNode *>, compare> minHeap;

    // Step 1: Create a leaf node for each character and insert it into the priority queue
    for (int i = 0; i < size; i++)
    {
        minHeap.push(new MinHeapNode(data[i], freq[i]));
    }

    // Step 2: Extract two minimum frequency nodes and combine them until only one node remains
    while (minHeap.size() != 1)
    {
        // Extract the two nodes with the lowest frequency
        left = minHeap.top();
        minHeap.pop();
        right = minHeap.top();
        minHeap.pop();

        // Create a new internal node with combined frequency and make it the parent of the two nodes
        temp = new MinHeapNode('$', left->freq + right->freq);
        temp->left = left;
        temp->right = right;

        // Insert the new node back into the priority queue
        minHeap.push(temp);
    }

    // Print Huffman codes from the root of the constructed Huffman Tree
    printCodes(minHeap.top(), "");
}

int main()
{
    // Character array and their corresponding frequencies
    char data[] = {'A', 'B', 'C', 'D'};
    int freq[] = {23, 12, 34, 10};
    int size = sizeof(data) / sizeof(data[0]);

    // Build Huffman Tree and generate codes
    HuffmanCode(data, freq, size);

    return 0;
}

/*
Huffman Coding:
- Time Complexity: O(nlogn), where n is the number of unique characters.
- Explanation: The priority queue performs extractMin() 2*(n - 1) times. Each extractMin() takes O(logn) time.
*/
