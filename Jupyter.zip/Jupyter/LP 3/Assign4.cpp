#include <bits/stdc++.h>
using namespace std;

// Function to check if placing a queen at arr[x][y] is safe
bool isSafe(int **arr, int x, int y, int n) {
    // Check the current column for any other queens placed above the current row
    for (int row = 0; row < x; row++) {
        if (arr[row][y] == 1) {
            return false;
        }
    }

    // Check the upper-left diagonal for any other queens
    int row = x;
    int col = y;
    while (row >= 0 && col >= 0) {
        if (arr[row][col] == 1) {
            return false;
        }
        row--;
        col--;
    }

    // Check the upper-right diagonal for any other queens
    row = x;
    col = y;
    while (row >= 0 && col < n) {
        if (arr[row][col] == 1) {
            return false;
        }
        row--;
        col++;
    }

    // If all checks passed, the position is safe for the queen
    return true;
}

// Function to print the current board arrangement of queens
void printBoard(int **arr, int n) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (arr[i][j] == 1) cout << "[Q]"; // Queen placed
            else cout << "[]"; // Empty cell
        }
        cout << endl;
    }
    cout << endl << endl;
}

// Recursive function to solve the N-Queen problem
void nQueen(int** arr, int x, int n) {
    // If all queens are placed, print the current board arrangement
    if (x == n) {
        printBoard(arr, n);
        return;
    }

    // Try placing a queen in each column of the current row 'x'
    for (int col = 0; col < n; col++) {
        if (isSafe(arr, x, col, n)) {
            arr[x][col] = 1; // Place queen at arr[x][col]
            nQueen(arr, x + 1, n); // Recurse for the next row
            arr[x][col] = 0; // Backtrack: remove queen from arr[x][col]
        }
    }
}

// Main function to initialize the board and start the N-Queen solution process
int main() {
    int n;
    cin >> n; // Input the size of the board (N x N)

    // Dynamically allocate a 2D array for the board, initialized to 0
    int **arr = new int*[n];
    for (int i = 0; i < n; i++) {
        arr[i] = new int[n];
        for (int j = 0; j < n; j++) {
            arr[i][j] = 0;
        }
    }

    // Call the recursive function to solve the N-Queen problem
    nQueen(arr, 0, n);
	
	cout << "--------All possible solutions--------";

    // Deallocate the dynamically allocated memory
    for (int i = 0; i < n; i++) {
        delete[] arr[i];
    }
    delete[] arr;

    return 0;
}

/*
Time Complexity: O(N!)
Explanation: The recursive backtracking approach tries all possible configurations, resulting in factorial time complexity.

Auxiliary Space: O(N^2)
Explanation: We use a 2D board of size N x N to store the positions of the queens.
*/
