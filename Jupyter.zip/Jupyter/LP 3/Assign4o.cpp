#include <bits/stdc++.h>
using namespace std;

// Define a maximum size for the board to avoid dynamic allocation
const int MAX = 10;
int arr[MAX][MAX];

// Function to check if placing a queen at arr[x][y] is safe
bool isSafe(int x, int y, int n)
{
    // Check the current column for any other queens placed above the current row
    for (int row = 0; row < x; row++)
    {
        if (arr[row][y] == 1)
        {
            return false;
        }
    }

    // Check the upper-left diagonal for any other queens
    int row = x;
    int col = y;
    while (row >= 0 && col >= 0)
    {
        if (arr[row][col] == 1)
        {
            return false;
        }
        row--;
        col--;
    }

    // Check the upper-right diagonal for any other queens
    row = x;
    col = y;
    while (row >= 0 && col < n)
    {
        if (arr[row][col] == 1)
        {
            return false;
        }
        row--;
        col++;
    }

    // If all checks passed, the position is safe for the queen
    return true;
}

// Function to print the current board arrangement of queens
void printBoard(int n)
{
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] == 1)
                cout << "[Q]"; // Queen placed
            else
                cout << "[]"; // Empty cell
        }
        cout << endl;
    }
    cout << endl
         << endl;
}

// Recursive function to solve the N-Queen problem
void nQueen(int x, int n)
{
    // If all queens are placed, print the current board arrangement
    if (x == n)
    {
        printBoard(n);
        return;
    }

    // Try placing a queen in each column of the current row 'x'
    for (int col = 0; col < n; col++)
    {
        if (isSafe(x, col, n))
        {
            arr[x][col] = 1;  // Place queen at arr[x][col]
            nQueen(x + 1, n); // Recurse for the next row
            arr[x][col] = 0;  // Backtrack: remove queen from arr[x][col]
        }
    }
}

// Main function to initialize the board and start the N-Queen solution process
int main()
{
    int n;
    cin >> n; // Input the size of the board (N x N)

    if (n < 4 && n != 1)
    {
        cout << "No solutions exist for N = " << n << ".\n";
        return 0;
    }

    // Initialize the board to 0
    memset(arr, 0, sizeof(arr));

    // Call the recursive function to solve the N-Queen problem
    nQueen(0, n);

    cout << "--------All possible solutions--------";

    return 0;
}

/*
Time Complexity: O(N!)
Auxiliary Space: O(N^2)
*/
